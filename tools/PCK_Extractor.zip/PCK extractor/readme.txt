~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      PCK - Extractor for Commandos 2 v0.7
        exklusive from: www.c2station.de
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

::Description
Program to extract the *.pck files in Commandos 2

::Licence for use
Freeware, free for commercial and non commercial use

::Licence for distribution
You can distribute this program, freely and without charge (onto CD-Roms, Websites, bulletin boards, etc.) provided that you do not change the program or the zip file (including this readme) in any way, that the program is clearly freeware or shareware, that you do not ask any money for the program itself.

::Words from the author
Now you can extract your commandos II pck files, to rip the music from
the game or do whatever you want with them. Please note that you at least
have to own a legal copy to extract the files.
I have not (yet) found a possibility to run the game from extracted files
instead of the pck-files, if someone figures out, please contact me:
mindelectric@hotmail.com
I will NOT answer any question regarding the usage of this software, don't
even try.

- This software comes with no warranty, use it at your own risk.
- You are not allowed to publish any material from the game in the internet, such as sounds or videos from the game.

::Up next
- repack your modified files to the pck file...


++++MANUAL

Just follow the instructions you get from the programm when you start it

++++ANLEITUNG

1) Das Programm starten
2) In das obere Eingabefeld das Verzeichnis des zu entpackenden PCK Files eingeben (z.B: D:\Games\Commandos 2\DATA.PCK)
3) In das untere Eingabefeld das Ausgabeverzeichnis der zu entpackenden Dateien eingeben (z.B: D:\C2 Unpack\PCK 1\)
4) Auf Unpack klicken und nen Kaffe trinken gehen...

Hinweise:
- Die Sounddateien befinden sich jeweils im Ordner 'SONIDOS'. Dieser befindet sich in beiden PCK Files (DATA.PCK und DATA2.PCK).
- In der DATA2.PCK sind nur Sounddateien enthalten.
- Die Videos werdet ihr nicht in den PCK Files finden, diese findet ihr im normalen C2 Verzeichnis, getarnt als *.POP Dateien. (\Commandos 2\DATA\WOFIP\) Die Pop Dateien k�nnt ihr durch einfaches umbenenen in AVI Dateien mit dem Windows Media Player anschauen
- Das ver�ffentlichen im Internet von entpackten Files ist aus Copyright-Gr�nden NICHT gestattet!
- Die entpackten Dateien sind genauso gro� wie ungepackt, ihr ben�tigt also soviel freien Speicherplatz zum entpacken der Files, wie diese gepackt gro� sind.

THX TO MIND FOR CODING THIS NICE PROGRAMM - KEEP UP THE GOOD WORK!

Program Author: Mindelectric
___________________________________________________________________
Program exklusive for: http://www.c2station.de
-------------------------------------------------------------------




