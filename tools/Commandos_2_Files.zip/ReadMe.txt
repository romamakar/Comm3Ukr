DON'T say you made this
DON'T change this whole .zip file
DON'T put your credits here if your hosting this file
DON'T ask money for this file
DON'T even think you may have this file if you are such a stinking pay-site as GameSpot or IGN
May the all mighty God tear your soul apart with his holy powers of fairness if you DON'T obey these rules!!

It took me a few hours to find, decode & order every game file that can be decoded. That are 1086 files mate.
I had to type every file name, because the tool I'm using doesn't allows dragging and dropping files into the executable.
I did you a favour, now do me a favour and obey the first 5 lines of this file.


How to use:
To make the changes have effect you should extract the .zip file to the installation dir of the game.
When your mod is done you should post it at the Eidos forums, where you can find even more link to mods, tools and sites!!

Credits:
Files have been decoded by Tom Sikking aka sick

Additional Credits:
jinshengmao 	for making a tool to decode the game files
marins 		for working hard on modding Commandos
everyone hosting this file without changing the contents

Links:
www.freewebs.com/pyrostudios
www.commandos.cenega.net/MMC/?lang=en
www.eidosinteractive.com/forums


